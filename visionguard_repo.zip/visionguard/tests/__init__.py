"""VisionGuard Automated Pytest Suite."""
